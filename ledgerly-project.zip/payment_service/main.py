import os, random
from decimal import Decimal
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
app = FastAPI(title='Ledgerly Payment Simulator', version='1.0.0', description='Demo-only payment finalization service. No real gateway is connected.')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['http://localhost:5173', 'http://127.0.0.1:5173'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
class PaymentRequest(BaseModel):
    transaction_id: int = Field(gt=0)
    amount: Decimal = Field(gt=0, decimal_places=2)
    force_status: str | None = None
class PaymentResponse(BaseModel):
    transaction_id: int
    status: str
    message: str
@app.get('/health')
def health(): return {'service':'payment-simulator','status':'ok'}
@app.post('/payments/simulate', response_model=PaymentResponse)
def simulate_payment(payload: PaymentRequest, authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(status_code=401, detail='JWT bearer token required')
    outcome = payload.force_status.upper() if payload.force_status else random.choice(['SUCCESS','FAILED'])
    if outcome not in {'SUCCESS','FAILED'}: raise HTTPException(status_code=422, detail='force_status must be SUCCESS or FAILED')
    return PaymentResponse(transaction_id=payload.transaction_id, status=outcome, message=f'Demo payment {outcome.lower()}')
