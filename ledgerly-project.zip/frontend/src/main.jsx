import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { LayoutDashboard, CreditCard, ArrowUpRight, History, LogOut, ShieldCheck, Plus, Search, CheckCircle2, Clock3, XCircle } from 'lucide-react';
import './styles.css';

const API_BASE = 'http://localhost:8000/api';
const PAYMENT_BASE = 'http://localhost:8001';
const CARD_LIMIT = 40000;
const seedTransactions = [
    { id: 'TXN-2048', merchant: 'R&R cafe', date: 'Today, 10:42 AM', amount: 840.0, status: 'SUCCESS' },
    { id: 'TXN-2047', merchant: 'Cloud Atlas', date: 'Yesterday, 3:18 PM', amount: 129.5, status: 'SUCCESS' },
    { id: 'TXN-2046', merchant: 'Maple & Co.', date: 'Sep 22, 8:06 AM', amount: 56.2, status: 'FAILED' }
];

const formatInr = (value) => new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
}).format(Number(value || 0));

const getStoredToken = () => localStorage.getItem('ledgerly_token') || '';

function App() {
    const [token, setToken] = useState(getStoredToken());
    const [authMode, setAuthMode] = useState('login');
    const [authForm, setAuthForm] = useState({ username: '', email: '', password: '' });
    const [authError, setAuthError] = useState('');
    const [active, setActive] = useState('overview');
    const [transactions, setTransactions] = useState(seedTransactions);
    const [cards, setCards] = useState([]);
    const [notice, setNotice] = useState('');
    const [showCard, setShowCard] = useState(false);
    const [showPayment, setShowPayment] = useState(false);
    const [selectedCardId, setSelectedCardId] = useState('');
    const [cardSpend, setCardSpend] = useState({});
    const [cardForm, setCardForm] = useState({ brand: 'Visa', card_number: '', cvv: '', expiry_month: '10', expiry_year: '2029' });
    const [paymentForm, setPaymentForm] = useState({ merchant: 'R&R cafe', amount: '40000', outcome: 'SUCCESS' });

    const total = transactions.filter((t) => t.status === 'SUCCESS').reduce((sum, t) => sum + Number(t.amount), 0);
    const spentProgress = Math.min(100, (total / CARD_LIMIT) * 100);
    const getCardSpent = (cardId) => Number(cardSpend[cardId] || 0);
    const getCardRemaining = (cardId) => Math.max(0, CARD_LIMIT - getCardSpent(cardId));
    const selectedCard = cards.find((card) => card.id === selectedCardId) || cards[0] || null;
    const remainingBalance = selectedCard ? getCardRemaining(selectedCard.id) : CARD_LIMIT;

    useEffect(() => {
        if (token) {
            localStorage.setItem('ledgerly_token', token);
        } else {
            localStorage.removeItem('ledgerly_token');
        }
    }, [token]);

    const fetchJson = async (url, options = {}) => {
        const headers = new Headers(options.headers || {});
        if (options.body && !headers.has('Content-Type')) {
            headers.set('Content-Type', 'application/json');
        }

        const response = await fetch(url, {
            ...options,
            headers
        });

        const contentType = response.headers.get('content-type') || '';
        const payload = contentType.includes('application/json') ? await response.json() : await response.text();

        if (!response.ok) {
            const message = typeof payload === 'string' ? payload : payload?.detail || payload?.non_field_errors || 'Request failed';
            throw new Error(message);
        }

        return payload;
    };

    const handleAuthSubmit = async (event) => {
        event.preventDefault();
        setAuthError('');

        try {
            if (authMode === 'register') {
                await fetchJson(`${API_BASE}/auth/register/`, {
                    method: 'POST',
                    body: JSON.stringify({
                        username: authForm.username,
                        email: authForm.email,
                        password: authForm.password
                    })
                });
                setAuthMode('login');
                setAuthForm({ ...authForm, email: '' });
                setNotice('Registration successful. Please log in.');
                setTimeout(() => setNotice(''), 3000);
                return;
            }

            const result = await fetchJson(`${API_BASE}/auth/token/`, {
                method: 'POST',
                body: JSON.stringify({
                    username: authForm.username,
                    password: authForm.password
                })
            });

            setToken(result.access);
            setAuthForm({ username: '', email: '', password: '' });
        } catch (error) {
            setAuthError(error.message);
        }
    };

    const loadCards = async () => {
        if (!token) return;
        try {
            const data = await fetchJson(`${API_BASE}/cards/`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setCards(data);
            if (data.length === 0) {
                setSelectedCardId('');
                return;
            }

            setSelectedCardId((current) => {
                if (current && data.some((card) => card.id === current)) {
                    return current;
                }
                return data[0].id;
            });
        } catch (error) {
            setNotice('Could not load cards.');
        }
    };

    const loadTransactions = async () => {
        if (!token) return;
        try {
            const data = await fetchJson(`${API_BASE}/transactions/`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setTransactions(data.map((item) => ({
                id: item.reference || item.id,
                merchant: item.merchant,
                date: new Date(item.created_at).toLocaleString(),
                amount: Number(item.amount),
                status: item.status
            })));
        } catch (error) {
            setNotice('Could not load transactions.');
        }
    };

    useEffect(() => {
        if (token) {
            loadCards();
            loadTransactions();
        }
    }, [token]);

    const handleCardSubmit = async (event) => {
        event.preventDefault();
        try {
            const savedCard = await fetchJson(`${API_BASE}/cards/`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    brand: cardForm.brand,
                    card_number: cardForm.card_number,
                    cvv: cardForm.cvv,
                    expiry_month: Number(cardForm.expiry_month),
                    expiry_year: Number(cardForm.expiry_year)
                })
            });

            const presetSpend = cards.length === 0 ? 39000 : 0;
            setCardSpend((current) => ({ ...current, [savedCard.id]: presetSpend }));
            setShowCard(false);
            setNotice('Card saved successfully.');
            setTimeout(() => setNotice(''), 3000);
            loadCards();
            setCardForm({ brand: 'Visa', card_number: '', cvv: '', expiry_month: '10', expiry_year: '2029' });
        } catch (error) {
            setNotice(error.message);
        }
    };

    const handleRemoveCard = async (cardId) => {
        try {
            await fetchJson(`${API_BASE}/cards/${cardId}/`, {
                method: 'DELETE',
                headers: { Authorization: `Bearer ${token}` }
            });

            const updated = cards.filter((card) => card.id !== cardId);
            setCards(updated);
            if (selectedCardId === cardId) {
                setSelectedCardId(updated[0]?.id || '');
            }
            setNotice('Card removed successfully.');
            setTimeout(() => setNotice(''), 2500);
        } catch (error) {
            setNotice(error.message);
        }
    };

    const handlePaymentSubmit = async (event) => {
        event.preventDefault();
        try {
            const amount = Number(paymentForm.amount);
            const limit = CARD_LIMIT;

            if (!Number.isFinite(amount) || amount <= 0) {
                throw new Error('Enter a valid payment amount.');
            }

            if (!selectedCard) {
                throw new Error('Please add a card before making a payment.');
            }

            const currentCardSpent = getCardSpent(selectedCard.id);
            const remainingForSelectedCard = Math.max(0, limit - currentCardSpent);

            if (amount > remainingForSelectedCard) {
                const failedEntry = {
                    id: `TXN-DECLINED-${Date.now()}`,
                    merchant: paymentForm.merchant || 'R&R cafe',
                    date: 'Just now',
                    amount,
                    status: 'FAILED'
                };

                setTransactions((current) => [failedEntry, ...current]);
                setShowPayment(false);
                setPaymentForm({ merchant: 'R&R cafe', amount: '40000', outcome: 'SUCCESS' });
                setNotice('Limit reached. Try after 24hrs.');
                setTimeout(() => setNotice(''), 4000);
                return;
            }

            if (cards.length > 1 && !selectedCardId) {
                throw new Error('Select a card to continue.');
            }

            const created = await fetchJson(`${API_BASE}/transactions/create/`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    merchant: paymentForm.merchant || 'R&R cafe',
                    amount
                })
            });

            const simulated = await fetchJson(`${PAYMENT_BASE}/payments/simulate`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    transaction_id: created.id,
                    amount,
                    force_status: paymentForm.outcome
                })
            });

            const updated = {
                id: created.reference || created.id,
                merchant: created.merchant,
                date: 'Just now',
                amount: Number(created.amount),
                status: simulated.status
            };

            setCardSpend((current) => ({
                ...current,
                [selectedCard.id]: (current[selectedCard.id] || 0) + amount
            }));
            setTransactions((current) => [updated, ...current]);
            setShowPayment(false);
            setPaymentForm({ merchant: 'R&R cafe', amount: '40000', outcome: 'SUCCESS' });
            setNotice(`Payment ${simulated.status.toLowerCase()} and recorded.`);
            setTimeout(() => setNotice(''), 3500);
        } catch (error) {
            setNotice(error.message);
        }
    };

    const signOut = () => {
        setToken('');
        setActive('overview');
        setNotice('Signed out successfully.');
        setTimeout(() => setNotice(''), 2000);
    };

    if (!token) {
        return (
            <div className="auth-shell">
                <div className="auth-card">
                    <div className="brand auth-brand">
                        <div className="brand-mark">L</div>
                        <span>ledgerly</span>
                    </div>
                    <h1>{authMode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
                    <p className="auth-subtitle">
                        {authMode === 'login'
                            ? 'Sign in to manage your cards and payments.'
                            : 'Register to use the demo payment console.'}
                    </p>

                    <div className="auth-tabs">
                        <button
                            className={authMode === 'login' ? 'auth-tab active' : 'auth-tab'}
                            onClick={() => setAuthMode('login')}
                        >
                            Login
                        </button>
                        <button
                            className={authMode === 'register' ? 'auth-tab active' : 'auth-tab'}
                            onClick={() => setAuthMode('register')}
                        >
                            Register
                        </button>
                    </div>

                    <form onSubmit={handleAuthSubmit} className="auth-form">
                        {authMode === 'register' && (
                            <label>
                                Email
                                <input
                                    type="email"
                                    value={authForm.email}
                                    onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })}
                                    required
                                />
                            </label>
                        )}

                        <label>
                            Username
                            <input
                                type="text"
                                value={authForm.username}
                                onChange={(event) => setAuthForm({ ...authForm, username: event.target.value })}
                                required
                            />
                        </label>

                        <label>
                            Password
                            <input
                                type="password"
                                value={authForm.password}
                                minLength={8}
                                onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })}
                                required
                            />
                        </label>

                        {authError && <div className="auth-error">{authError}</div>}
                        {notice && <div className="auth-success">{notice}</div>}

                        <button type="submit" className="primary-button full">
                            {authMode === 'login' ? 'Login' : 'Register'}
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    return (
        <div className="app-shell">
            <aside className="sidebar">
                <div className="brand">
                    <div className="brand-mark">RA</div>
                    <span>ledgerly</span>
                </div>
                <div className="workspace-label">WORKSPACE</div>
                <nav>
                    {[['overview', 'Overview', LayoutDashboard], ['cards', 'My cards', CreditCard], ['pay', 'Make payment', ArrowUpRight], ['history', 'Transactions', History]].map(([key, label, Icon]) => (
                        <button key={key} className={active === key ? 'nav-item active' : 'nav-item'} onClick={() => key === 'pay' ? setShowPayment(true) : setActive(key)}>
                            <Icon size={18} />{label}{key === 'history' && <span className="nav-count">{transactions.length}</span>}
                        </button>
                    ))}
                </nav>
                <div className="sidebar-bottom">
                    <div className="security-chip">
                        <div>
                            <strong>Protected</strong>
                            <small>JWT secured session</small>
                        </div>
                    </div>
                    <button className="nav-item logout" onClick={signOut}><LogOut size={18} />Sign out</button>
                </div>
            </aside>

            <main className="main">
                <header className="topbar">
                    <div>
                        <p className="eyebrow">Friday, September 25, 2026</p>
                        <h1>{active === 'overview' ? 'Good morning, Rithish.' : 'Your ' + (active === 'cards' ? 'cards' : active === 'history' ? 'transactions' : 'account')}</h1>
                    </div>
                    <div className="top-actions">
                        <button className="icon-button" aria-label="Search"><Search size={18} /></button>
                        <div className="avatar">RA</div>
                    </div>
                </header>

                {notice && <div className="notice"><CheckCircle2 size={18} />{notice}</div>}

                {active === 'overview' && (
                    <>
                        <section className="hero-row">
                            <div className="balance-panel">
                                <div className="panel-kicker">AVAILABLE BALANCE <span>INR</span></div>
                                <div className="balance">{formatInr(total)}</div>
                                <div className="balance-meta">
                                    <span><i className="dot green" />Synced moments ago</span>
                                    <span>Limit {formatInr(CARD_LIMIT)}</span>
                                </div>
                                <div className="limit-track"><div style={{ width: `${Math.min(100, spentProgress)}%` }} /></div>
                            </div>

                            <div className="quick-panel">
                                <p className="panel-kicker">QUICK ACTION</p>
                                <h3>Move money with confidence.</h3>
                                <button className="primary-button" onClick={() => setShowPayment(true)}>New payment</button>
                            </div>
                        </section>

                        <div className="section-heading">
                            <div>
                                <p className="panel-kicker">RECENT ACTIVITY</p>
                                <h2>Latest transactions</h2>
                            </div>
                            <button className="filter-button" onClick={() => setActive('history')}>View all</button>
                        </div>

                        <TransactionTable transactions={transactions.slice(0, 5)} />
                    </>
                )}

                {active === 'cards' && (
                    <>
                        <div className="section-heading">
                            <div>
                                <p className="panel-kicker">MANAGED CARDS</p>
                                <h2>Saved cards</h2>
                            </div>
                            <button className="primary-button" onClick={() => setShowCard(true)}><Plus size={16} />Add card</button>
                        </div>

                        <div className="cards-grid">
                            {cards.length === 0 ? (
                                <div className="empty-state">No cards saved yet.</div>
                            ) : cards.map((card) => (
                                <div key={card.id} className="credit-card">
                                    <div className="card-top">
                                        <span>{card.brand}</span>
                                        <span>Limit {formatInr(CARD_LIMIT)}</span>
                                    </div>
                                    <div className="chip" />
                                    <div className="card-number">{card.masked_number}</div>
                                    <div className="card-bottom">
                                        <span>Card holder</span>
                                        <span>•••• {card.last_four}</span>
                                    </div>
                                    <button type="button" className="remove-card-button" onClick={() => handleRemoveCard(card.id)}>
                                        Remove card
                                    </button>
                                </div>
                            ))}
                        </div>
                    </>
                )}

                {active === 'history' && (
                    <>
                        <div className="section-heading">
                            <div>
                                <p className="panel-kicker">TRANSACTION HISTORY</p>
                                <h2>All payments</h2>
                            </div>
                            <button className="filter-button">Filter</button>
                        </div>
                        <TransactionTable transactions={transactions} />
                    </>
                )}
            </main>

            {showCard && (
                <Modal title="Add card" onClose={() => setShowCard(false)}>
                    <form onSubmit={handleCardSubmit}>
                        <label>
                            Card brand
                            <select value={cardForm.brand} onChange={(event) => setCardForm({ ...cardForm, brand: event.target.value })}>
                                <option>Visa</option>
                                <option>Mastercard</option>
                                <option>Amex</option>
                            </select>
                        </label>
                        <label>
                            Card number
                            <input value={cardForm.card_number} onChange={(event) => setCardForm({ ...cardForm, card_number: event.target.value })} placeholder="4111 1111 1111 1111" required />
                        </label>
                        <div className="form-row">
                            <label>
                                CVV
                                <input value={cardForm.cvv} onChange={(event) => setCardForm({ ...cardForm, cvv: event.target.value })} placeholder="123" required />
                            </label>
                            <label>
                                Expiry year
                                <input value={cardForm.expiry_year} onChange={(event) => setCardForm({ ...cardForm, expiry_year: event.target.value })} required />
                            </label>
                        </div>
                        <label>
                            Expiry month
                            <input value={cardForm.expiry_month} onChange={(event) => setCardForm({ ...cardForm, expiry_month: event.target.value })} required />
                        </label>
                        <button className="primary-button full" type="submit">Save card</button>
                    </form>
                </Modal>
            )}

            {showPayment && (
                <Modal title="Make payment" onClose={() => setShowPayment(false)}>
                    <form onSubmit={handlePaymentSubmit}>
                        {cards.length > 1 ? (
                            <label>
                                Select card
                                <select value={selectedCardId} onChange={(event) => setSelectedCardId(event.target.value)}>
                                    {cards.map((card) => (
                                        <option key={card.id} value={card.id}>{card.brand} •••• {card.last_four}</option>
                                    ))}
                                </select>
                            </label>
                        ) : cards.length === 1 ? (
                            <div className="selected-card-summary">
                                Paying with {cards[0].brand} •••• {cards[0].last_four}
                            </div>
                        ) : null}

                        {selectedCard && (
                            <div className="selected-card-summary">
                                Remaining on selected card: {formatInr(getCardRemaining(selectedCard.id))}
                            </div>
                        )}

                        <label>
                            Merchant
                            <input value={paymentForm.merchant} onChange={(event) => setPaymentForm({ ...paymentForm, merchant: event.target.value })} required />
                        </label>
                        <div className="form-row">
                            <label>
                                Amount
                                <input type="number" step="0.01" min="0" max={CARD_LIMIT} value={paymentForm.amount} onChange={(event) => setPaymentForm({ ...paymentForm, amount: event.target.value })} required />
                            </label>
                            <label>
                                Outcome
                                <select value={paymentForm.outcome} onChange={(event) => setPaymentForm({ ...paymentForm, outcome: event.target.value })}>
                                    <option value="SUCCESS">SUCCESS</option>
                                    <option value="FAILED">FAILED</option>
                                </select>
                            </label>
                        </div>
                        <p className="simulation-note"><CheckCircle2 size={15} />Demo-only payment simulator. No real gateway is used.</p>
                        <button className="primary-button full" type="submit">Submit payment</button>
                    </form>
                </Modal>
            )}
        </div>
    );
}

function TransactionTable({ transactions }) {
    return (
        <div className="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Transaction</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions.map((t) => (
                        <tr key={t.id}>
                            <td>
                                <strong>{t.merchant}</strong>
                                <small>{t.id}</small>
                            </td>
                            <td>{t.date}</td>
                            <td className="amount">{formatInr(t.amount)}</td>
                            <td>
                                <span className={`status ${t.status.toLowerCase()}`}>
                                    {t.status === 'SUCCESS' ? <CheckCircle2 size={14} /> : t.status === 'FAILED' ? <XCircle size={14} /> : <Clock3 size={14} />}
                                    {t.status}
                                </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

function Modal({ title, onClose, children }) {
    return (
        <div className="modal-backdrop" onMouseDown={onClose}>
            <div className="modal" onMouseDown={(event) => event.stopPropagation()}>
                <div className="modal-head">
                    <h2>{title}</h2>
                    <button className="close" onClick={onClose}>×</button>
                </div>
                {children}
            </div>
        </div>
    );
}

const rootElement = document.getElementById('root');
const root = globalThis.__ledgerlyRoot ?? createRoot(rootElement);
globalThis.__ledgerlyRoot = root;
root.render(<App />);
