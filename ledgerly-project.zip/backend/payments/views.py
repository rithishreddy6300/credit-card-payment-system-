import csv, uuid
from django.contrib.auth.models import User
from django.db.models import Sum
from django.http import HttpResponse
from django.utils.dateparse import parse_date
from rest_framework import generics, permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from .models import Card, Transaction, AdminLog
from .serializers import RegisterSerializer, CardSerializer, TransactionSerializer
class RegisterView(generics.CreateAPIView): queryset=User.objects.all(); serializer_class=RegisterSerializer; permission_classes=[permissions.AllowAny]
class CardListCreateView(generics.ListCreateAPIView):
    serializer_class=CardSerializer
    def get_queryset(self): return Card.objects.filter(user=self.request.user)
class CardDeleteView(generics.DestroyAPIView):
    serializer_class=CardSerializer
    def get_queryset(self): return Card.objects.filter(user=self.request.user)
class TransactionListView(generics.ListAPIView):
    serializer_class=TransactionSerializer
    def get_queryset(self):
        qs=Transaction.objects.filter(user=self.request.user).order_by('-created_at')
        params=self.request.query_params
        if params.get('status'): qs=qs.filter(status=params['status'].upper())
        if params.get('min_amount'): qs=qs.filter(amount__gte=params['min_amount'])
        if params.get('max_amount'): qs=qs.filter(amount__lte=params['max_amount'])
        if params.get('date'): qs=qs.filter(created_at__date=parse_date(params['date']))
        return qs
@api_view(['POST'])
def create_transaction(request):
    serializer=TransactionSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)
    transaction=serializer.save(user=request.user, reference=f'TXN-{uuid.uuid4().hex[:10].upper()}')
    return Response(TransactionSerializer(transaction).data, status=status.HTTP_201_CREATED)
@api_view(['GET'])
@permission_classes([permissions.IsAdminUser])
def admin_summary(request):
    data=Transaction.objects.filter(status='SUCCESS').aggregate(total=Sum('amount'), count=Sum('id'))
    return Response({'successful_amount': data['total'] or 0, 'successful_count': data['count'] or 0, 'users': User.objects.count(), 'cards': Card.objects.count()})
@api_view(['GET'])
@permission_classes([permissions.IsAdminUser])
def export_transactions(request):
    response=HttpResponse(content_type='text/csv'); response['Content-Disposition']='attachment; filename="transactions.csv"'; writer=csv.writer(response); writer.writerow(['reference','user','merchant','amount','status','created_at'])
    for item in Transaction.objects.select_related('user').all(): writer.writerow([item.reference,item.user.username,item.merchant,item.amount,item.status,item.created_at.isoformat()])
    AdminLog.objects.create(actor=request.user, action='Exported transactions to CSV'); return response
