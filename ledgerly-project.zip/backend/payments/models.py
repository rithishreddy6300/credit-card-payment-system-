from django.contrib.auth.models import User
from django.db import models
class Card(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='cards')
    brand = models.CharField(max_length=30)
    masked_number = models.CharField(max_length=25)
    last_four = models.CharField(max_length=4)
    expiry_month = models.PositiveSmallIntegerField()
    expiry_year = models.PositiveSmallIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
class Transaction(models.Model):
    STATUS_CHOICES = [('PENDING','Pending'),('SUCCESS','Success'),('FAILED','Failed')]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transactions')
    merchant = models.CharField(max_length=120)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='PENDING')
    reference = models.CharField(max_length=40, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
class AdminLog(models.Model):
    actor = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=120)
    created_at = models.DateTimeField(auto_now_add=True)
