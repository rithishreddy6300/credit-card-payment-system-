from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework.test import APITestCase
from .models import Card, Transaction

class PaymentApiTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='tester', password='StrongPass123!')
        self.admin = User.objects.create_superuser(username='admin', email='admin@example.com', password='AdminPass123!')
        self.client.force_authenticate(self.user)

    def test_card_is_masked_and_cvv_is_not_persisted(self):
        response = self.client.post('/api/cards/', {'brand':'VISA','card_number':'4242424242424242','cvv':'123','expiry_month':9,'expiry_year':2028}, format='json')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data['last_four'], '4242')
        self.assertNotIn('cvv', response.data)
        self.assertEqual(Card.objects.get().masked_number, '**** **** **** 4242')

    def test_transaction_starts_pending(self):
        response = self.client.post('/api/transactions/create/', {'merchant':'Test Merchant','amount':'20.00'}, format='json')
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data['status'], 'PENDING')

    def test_transaction_list_filters_by_amount_status_and_date(self):
        Transaction.objects.create(user=self.user, merchant='Northwind Studio', amount='250.00', status='SUCCESS', reference='TXN-FILTER-1')
        Transaction.objects.create(user=self.user, merchant='Cloud Atlas', amount='75.00', status='FAILED', reference='TXN-FILTER-2')

        response = self.client.get('/api/transactions/?status=SUCCESS&min_amount=100&max_amount=300&date=2026-09-25')

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['merchant'], 'Northwind Studio')

    def test_admin_summary_and_export_are_available_to_superusers(self):
        self.client.force_authenticate(self.admin)

        summary = self.client.get('/api/admin/summary/')
        self.assertEqual(summary.status_code, 200)
        self.assertIn('successful_amount', summary.data)

        export = self.client.get('/api/admin/transactions/export/')
        self.assertEqual(export.status_code, 200)
        self.assertIn('reference', export.content.decode('utf-8').splitlines()[0])
