from django.urls import path
from .views import RegisterView, CardListCreateView, CardDeleteView, TransactionListView, create_transaction, admin_summary, export_transactions
urlpatterns = [path('auth/register/', RegisterView.as_view()), path('cards/', CardListCreateView.as_view()), path('cards/<int:pk>/', CardDeleteView.as_view()), path('transactions/', TransactionListView.as_view()), path('transactions/create/', create_transaction), path('admin/summary/', admin_summary), path('admin/transactions/export/', export_transactions)]
