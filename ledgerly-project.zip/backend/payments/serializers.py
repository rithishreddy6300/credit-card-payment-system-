from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Card, Transaction
class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    class Meta: model = User; fields = ('username','email','password')
    def create(self, validated_data): return User.objects.create_user(**validated_data)
class CardSerializer(serializers.ModelSerializer):
    class Meta: model = Card; fields = ('id','brand','masked_number','last_four','expiry_month','expiry_year','created_at','card_number','cvv'); read_only_fields = ('id','masked_number','last_four','created_at')
    card_number = serializers.CharField(write_only=True, min_length=12, max_length=19)
    cvv = serializers.CharField(write_only=True, min_length=3, max_length=4)
    def create(self, validated_data):
        card_number = ''.join(c for c in validated_data.pop('card_number') if c.isdigit()); validated_data.pop('cvv')
        if len(card_number) < 12: raise serializers.ValidationError({'card_number':'Enter a valid card number.'})
        validated_data.update(masked_number=f'**** **** **** {card_number[-4:]}', last_four=card_number[-4:])
        return Card.objects.create(**validated_data, user=self.context['request'].user)
class TransactionSerializer(serializers.ModelSerializer):
    class Meta: model = Transaction; fields = '__all__'; read_only_fields = ('user','reference','status','created_at','updated_at')
